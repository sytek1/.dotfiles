static float clamp(float value, float lower, float upper);
static void changealpha(const Arg *);
