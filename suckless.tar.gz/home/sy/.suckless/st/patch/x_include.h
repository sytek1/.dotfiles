/* Patches */
#include "alpha.h"
