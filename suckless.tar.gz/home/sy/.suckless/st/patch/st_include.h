/* Patches */
#include "scrollback.h"
// #if VIM_BROWSE_PATCH
// #include "normalMode.h"
// #endif
